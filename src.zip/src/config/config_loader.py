"""Simplified YAML config loader inspired by lightning-hydra-template."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


CONFIG_DIR = Path(__file__).resolve().parent


def load_config(name: str = "experiment", overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    path = CONFIG_DIR / f"{name}.yaml"
    if not path.exists():
        path = CONFIG_DIR / name
    with path.open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    cfg = deepcopy(cfg)
    for key, value in (overrides or {}).items():
        set_by_dotted_key(cfg, key, value)
    return cfg


def set_by_dotted_key(cfg: dict[str, Any], key: str, value: Any) -> None:
    current = cfg
    parts = key.split(".")
    for part in parts[:-1]:
        current = current.setdefault(part, {})
    current[parts[-1]] = value


def merge_dicts(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = merge_dicts(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged

