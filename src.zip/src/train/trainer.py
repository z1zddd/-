"""Trainer skeleton adapted from lightning-hydra-template and train_tcn_multivar.py."""

from __future__ import annotations

from copy import deepcopy

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset


class Trainer:
    def __init__(
        self,
        model,
        loss_fn,
        optimizer,
        device: str | torch.device = "cpu",
        callbacks: list | None = None,
        batch_size: int = 32,
        epochs: int = 50,
        patience: int = 8,
        grad_clip: float = 1.0,
    ):
        self.model = model
        self.loss_fn = loss_fn
        self.optimizer = optimizer
        self.device = torch.device(device)
        self.callbacks = callbacks or []
        self.batch_size = batch_size
        self.epochs = epochs
        self.patience = patience
        self.grad_clip = grad_clip

    def train(self, X_train, y_train, X_val=None, y_val=None):
        self.model.to(self.device)
        train_loader = DataLoader(
            TensorDataset(torch.as_tensor(X_train, dtype=torch.float32), torch.as_tensor(y_train, dtype=torch.float32).view(-1, 1)),
            batch_size=self.batch_size,
            shuffle=True,
        )
        valid_x = torch.as_tensor(X_val if X_val is not None else X_train, dtype=torch.float32, device=self.device)
        valid_y = torch.as_tensor(y_val if y_val is not None else y_train, dtype=torch.float32, device=self.device).view(-1, 1)

        best_state = deepcopy(self.model.state_dict())
        best_valid = float("inf")
        stale = 0
        history = {"train_loss": [], "val_loss": []}
        for _epoch in range(1, self.epochs + 1):
            self.model.train()
            losses = []
            for xb, yb in train_loader:
                xb = xb.to(self.device)
                yb = yb.to(self.device)
                self.optimizer.zero_grad(set_to_none=True)
                loss = self.loss_fn(self.model(xb), yb)
                loss.backward()
                if self.grad_clip:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip)
                self.optimizer.step()
                losses.append(float(loss.detach().cpu()))
            self.model.eval()
            with torch.no_grad():
                val_loss = float(self.loss_fn(self.model(valid_x), valid_y).detach().cpu())
            train_loss = float(np.mean(losses))
            history["train_loss"].append(train_loss)
            history["val_loss"].append(val_loss)
            if val_loss < best_valid:
                best_valid = val_loss
                best_state = deepcopy(self.model.state_dict())
                stale = 0
            else:
                stale += 1
                if stale >= self.patience:
                    break

        self.model.load_state_dict(best_state)
        history["best_val_loss"] = best_valid
        return self.model, history

