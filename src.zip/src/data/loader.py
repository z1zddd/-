"""Commodity CSV loader adapted from Time-Series-Library data_provider/data_loader.py.

Only the project-specific path, feature columns, and future-price target creation
are changed. Time marker tensors are intentionally removed for this framework.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer

from src.data.windower import make_windows


DEFAULT_FEATURES = [
    "dce_corn_close",
    "dce_corn_volume",
    "dce_corn_open_interest",
    "dce_corn_starch_close",
    "domestic_corn_spot_price_cny_t",
    "corn_basis_cny_t",
    "cbot_corn_close",
    "cbot_wheat_close",
    "ne_avg_precip_mm",
    "ne_avg_t2m_c",
]


def resolve_input_path(csv_path: str | Path) -> Path:
    candidates = [Path(csv_path), Path("data/raw") / Path(csv_path).name]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"CSV not found. Tried: {', '.join(str(p) for p in candidates)}")


def load_real_data(csv_path: str | Path, feature_cols: list[str] | None = None) -> tuple[pd.DataFrame, list[str]]:
    path = resolve_input_path(csv_path)
    df = pd.read_csv(path)
    if "date" not in df.columns:
        raise ValueError("Input CSV must contain a date column.")
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").reset_index(drop=True)

    selected = list(feature_cols or DEFAULT_FEATURES)
    missing = [c for c in selected if c not in df.columns]
    if missing:
        raise ValueError(f"Missing feature columns: {missing}")
    return df, selected


def add_future_price_target(
    df: pd.DataFrame,
    price_col: str = "dce_corn_close",
    horizon: int = 30,
    target_col: str = "target_price_fwd",
) -> pd.DataFrame:
    out = df.copy()
    out[target_col] = out[price_col].shift(-horizon)
    out["target_return_fwd"] = out[target_col] / out[price_col] - 1.0
    out["target_direction_fwd"] = (out["target_return_fwd"] > 0).astype("float32")
    return out


def load_and_window(config: dict) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    csv_path = config.get("csv_path", "data/raw/corn_daily_enriched.csv")
    feature_cols = config.get("feature_cols") or DEFAULT_FEATURES
    seq_len = int(config.get("seq_len", config.get("window_len", 30)))
    horizon = int(config.get("horizon", 30))
    include_today = bool(config.get("include_today", True))
    target_mode = config.get("target_mode", "price")
    price_col = config.get("price_col", "dce_corn_close")

    df, feature_cols = load_real_data(csv_path, feature_cols)
    target_col = str(config.get("target_col") or ("target_direction_fwd" if target_mode == "classification" else "target_price_fwd"))
    if target_col not in df.columns:
        df = add_future_price_target(df, price_col=price_col, horizon=horizon)

    imputer = SimpleImputer(strategy=config.get("impute_strategy", "median"))
    df[feature_cols] = imputer.fit_transform(df[feature_cols])
    x, y, meta = make_windows(
        df=df,
        feature_cols=feature_cols,
        target_col=target_col,
        seq_len=seq_len,
        horizon=horizon,
        include_today=include_today,
        today_col=price_col,
    )
    meta["feature_cols"] = [feature_cols] * len(meta)
    meta.attrs["feature_cols"] = feature_cols
    meta.attrs["csv_path"] = str(resolve_input_path(csv_path))
    meta.attrs["target_col"] = target_col
    return x, y, meta

