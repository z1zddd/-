"""Standardizer interface expected by the original LSTM pipeline.

The file named in the supervision document was not present on this machine.
This class keeps the same small fit/transform/inverse_transform contract used
by the existing project scripts through sklearn's StandardScaler pattern.
"""

from __future__ import annotations

import pickle
from pathlib import Path

import numpy as np


class Standardizer:
    """Z-score standardizer with a numpy-friendly API."""

    def __init__(self, eps: float = 1e-8):
        self.eps = eps
        self.mean_: np.ndarray | None = None
        self.std_: np.ndarray | None = None

    def fit(self, x: np.ndarray) -> "Standardizer":
        arr = np.asarray(x, dtype=np.float32)
        self.mean_ = np.nanmean(arr, axis=0)
        self.std_ = np.nanstd(arr, axis=0)
        self.std_ = np.where(self.std_ < self.eps, 1.0, self.std_)
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        self._check_fitted()
        return ((np.asarray(x, dtype=np.float32) - self.mean_) / self.std_).astype("float32")

    def inverse_transform(self, x: np.ndarray) -> np.ndarray:
        self._check_fitted()
        return (np.asarray(x, dtype=np.float32) * self.std_ + self.mean_).astype("float32")

    def fit_transform(self, x: np.ndarray) -> np.ndarray:
        return self.fit(x).transform(x)

    def save(self, path: str | Path) -> None:
        with Path(path).open("wb") as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls, path: str | Path) -> "Standardizer":
        with Path(path).open("rb") as f:
            return pickle.load(f)

    def _check_fitted(self) -> None:
        if self.mean_ is None or self.std_ is None:
            raise RuntimeError("Standardizer must be fitted before transform.")

