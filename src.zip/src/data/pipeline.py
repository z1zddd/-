"""DataPipeline combines loader, splitter, and scaler into one contract."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from src.data.loader import load_and_window
from src.data.scaler import Standardizer
from src.data.splitter import time_split


@dataclass
class DataBundle:
    X_train: np.ndarray
    y_train: np.ndarray
    X_val: np.ndarray
    y_val: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray
    scaler: Standardizer
    y_scaler: Standardizer
    meta_train: object
    meta_val: object
    meta_test: object
    feature_cols: list[str]


class DataPipeline:
    def __init__(self, config: dict):
        self.config = config

    def run(self) -> DataBundle:
        x, y, meta = load_and_window(self.config)
        train_idx, val_idx, test_idx = time_split(
            meta["date"],
            method=self.config.get("split_method", "fixed_date"),
            test_start=self.config.get("test_start", "2024-01-01"),
            train_ratio=float(self.config.get("train_ratio", 0.8)),
            val_ratio=float(self.config.get("val_ratio", 0.1)),
        )

        scaler = Standardizer()
        y_scaler = Standardizer()
        flat_train = x[train_idx].transpose(0, 2, 1).reshape(-1, x.shape[1])
        scaler.fit(flat_train)
        x_scaled = self._transform_x(x, scaler)

        if self.config.get("scale_y", True):
            y_scaler.fit(y[train_idx].reshape(-1, 1))
            y_out = y_scaler.transform(y.reshape(-1, 1)).reshape(-1)
        else:
            y_scaler.fit(np.zeros((1, 1), dtype="float32"))
            y_out = y.astype("float32")

        feature_cols = meta.attrs.get("feature_cols", self.config.get("feature_cols", []))
        return DataBundle(
            X_train=x_scaled[train_idx],
            y_train=y_out[train_idx],
            X_val=x_scaled[val_idx],
            y_val=y_out[val_idx],
            X_test=x_scaled[test_idx],
            y_test=y_out[test_idx],
            scaler=scaler,
            y_scaler=y_scaler,
            meta_train=meta.iloc[train_idx].reset_index(drop=True),
            meta_val=meta.iloc[val_idx].reset_index(drop=True),
            meta_test=meta.iloc[test_idx].reset_index(drop=True),
            feature_cols=list(feature_cols),
        )

    @staticmethod
    def _transform_x(x: np.ndarray, scaler: Standardizer) -> np.ndarray:
        n, v, t = x.shape
        flat = x.transpose(0, 2, 1).reshape(-1, v)
        scaled = scaler.transform(flat).reshape(n, t, v).transpose(0, 2, 1)
        return scaled.astype("float32")

