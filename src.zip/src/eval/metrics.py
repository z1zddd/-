"""Metrics copied from Time-Series-Library utils/metrics.py and extended for trading."""

from __future__ import annotations

import numpy as np


def RSE(pred, true):
    return np.sqrt(np.sum((true - pred) ** 2)) / np.sqrt(np.sum((true - true.mean()) ** 2))


def CORR(pred, true):
    u = ((true - true.mean(0)) * (pred - pred.mean(0))).sum(0)
    d = np.sqrt(((true - true.mean(0)) ** 2 * (pred - pred.mean(0)) ** 2).sum(0))
    return (u / d).mean(-1)


def MAE(pred, true):
    return np.mean(np.abs(true - pred))


def MSE(pred, true):
    return np.mean((true - pred) ** 2)


def RMSE(pred, true):
    return np.sqrt(MSE(pred, true))


def MAPE(pred, true):
    return np.mean(np.abs((true - pred) / np.where(true == 0, np.nan, true)))


def MSPE(pred, true):
    return np.mean(np.square((true - pred) / np.where(true == 0, np.nan, true)))


def metric(pred, true):
    mae = MAE(pred, true)
    mse = MSE(pred, true)
    rmse = RMSE(pred, true)
    mape = MAPE(pred, true)
    mspe = MSPE(pred, true)
    return mae, mse, rmse, mape, mspe


def max_drawdown(equity: np.ndarray) -> float:
    peak = np.maximum.accumulate(equity)
    drawdown = equity / np.where(peak == 0, 1.0, peak) - 1.0
    return float(np.nanmin(drawdown))


def sharpe_ratio(returns: np.ndarray, periods_per_year: int = 252) -> float:
    std = np.nanstd(returns)
    if std == 0 or np.isnan(std):
        return 0.0
    return float(np.nanmean(returns) / std * np.sqrt(periods_per_year))


def evaluate_model(y_true, y_pred, today_close, periods_per_year: int = 252) -> dict[str, float]:
    y_true = np.asarray(y_true, dtype=float).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=float).reshape(-1)
    today_close = np.asarray(today_close, dtype=float).reshape(-1)
    true_dir = (y_true > today_close).astype(int)
    pred_dir = (y_pred > today_close).astype(int)
    actual_return = y_true / today_close - 1.0
    position = np.where(pred_dir == 1, 1.0, -1.0)
    strategy_return = position * actual_return
    gross_profit = strategy_return[strategy_return > 0].sum()
    gross_loss = np.abs(strategy_return[strategy_return < 0].sum())
    equity = np.cumprod(1.0 + np.nan_to_num(strategy_return, nan=0.0))

    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return {
        "direction_accuracy": float(np.mean(true_dir == pred_dir)),
        "profit_factor": float(gross_profit / gross_loss) if gross_loss > 0 else float("inf"),
        "sharpe_ratio": sharpe_ratio(strategy_return, periods_per_year=periods_per_year),
        "win_rate": float(np.mean(strategy_return > 0)),
        "max_drawdown": max_drawdown(equity),
        "rmse": float(RMSE(y_pred, y_true)),
        "mae": float(MAE(y_pred, y_true)),
        "r2": float(1.0 - ss_res / ss_tot) if ss_tot else 0.0,
    }


def compare_models(results_dict: dict[str, dict[str, float]]):
    import pandas as pd

    order = ["direction_accuracy", "profit_factor", "sharpe_ratio", "win_rate", "max_drawdown", "rmse", "mae", "r2"]
    rows = []
    for model, metrics in results_dict.items():
        row = {"model": model}
        row.update({k: metrics.get(k) for k in order})
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["direction_accuracy", "profit_factor"], ascending=[False, False])

