"""Report writer for predictions, metrics, comparison CSVs, and equity curves."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.eval.metrics import evaluate_model


def generate_report(y_true, y_pred, today_close, model_name: str, output_dir: str | Path, meta=None) -> dict[str, float]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    y_true = np.asarray(y_true, dtype=float).reshape(-1)
    y_pred = np.asarray(y_pred, dtype=float).reshape(-1)
    today_close = np.asarray(today_close, dtype=float).reshape(-1)

    actual_return = y_true / today_close - 1.0
    pred_dir = y_pred > today_close
    actual_dir = y_true > today_close
    strategy_return = np.where(pred_dir, actual_return, -actual_return)
    frame = pd.DataFrame(
        {
            "today_price": today_close,
            "actual_price": y_true,
            "pred_price": y_pred,
            "actual_direction": np.where(actual_dir, "UP", "DOWN"),
            "pred_direction": np.where(pred_dir, "UP", "DOWN"),
            "direction_correct": (actual_dir == pred_dir).astype(int),
            "actual_return": actual_return,
            "strategy_return": strategy_return,
        }
    )
    if meta is not None:
        meta_frame = pd.DataFrame(meta).reset_index(drop=True)
        for col in ["date", "target_date"]:
            if col in meta_frame:
                frame[col] = pd.to_datetime(meta_frame[col]).dt.strftime("%Y-%m-%d")
        if "date" in frame:
            frame = frame.rename(columns={"date": "today_date"})
        ordered = [
            "today_date",
            "target_date",
            "today_price",
            "actual_price",
            "pred_price",
            "actual_direction",
            "pred_direction",
            "direction_correct",
            "actual_return",
            "strategy_return",
        ]
        frame = frame[[c for c in ordered if c in frame.columns]]

    frame["equity"] = (1 + frame["strategy_return"]).cumprod()
    frame.to_csv(output / "predictions.csv", index=False)
    metrics = evaluate_model(y_true, y_pred, today_close)
    (output / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame([{"model": model_name, **metrics}]).to_csv(output / "metrics.csv", index=False)
    plot_equity(frame, output / "equity_curve.png", model_name)
    return metrics


def plot_equity(frame: pd.DataFrame, path: str | Path, title: str) -> None:
    fig, ax = plt.subplots(figsize=(10, 5))
    x = pd.to_datetime(frame["today_date"]) if "today_date" in frame else np.arange(len(frame))
    ax.plot(x, frame["equity"], label="strategy")
    ax.set_title(f"{title} equity curve")
    ax.set_ylabel("Equity")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
