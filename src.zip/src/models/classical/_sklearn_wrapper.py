"""sklearn-style wrappers following darts RegressionModel's flattened-window pattern."""

from __future__ import annotations

import numpy as np

from src.models.base import BaseModel


class SklearnWindowModel(BaseModel):
    def __init__(self, model, task: str = "regression"):
        self.model = model
        self.task = task

    def fit(self, X_train, y_train, X_val=None, y_val=None):
        self.model.fit(self._flatten(X_train), np.asarray(y_train).reshape(-1))
        return self

    def predict(self, X) -> np.ndarray:
        x = self._flatten(X)
        if self.task == "classification" and hasattr(self.model, "predict_proba"):
            return self.model.predict_proba(x)[:, 1].astype("float32")
        return np.asarray(self.model.predict(x), dtype="float32").reshape(-1)

    @staticmethod
    def _flatten(X) -> np.ndarray:
        arr = np.asarray(X, dtype=np.float32)
        return arr.reshape(arr.shape[0], -1)

