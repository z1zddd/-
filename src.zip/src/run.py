"""Unified experiment entry point.

The structure follows lightning-hydra-template's single train entry idea, but
uses a small YAML loader so this project can run without Hydra.
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import random
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from src.config.config_loader import load_config, merge_dicts
from src.data.pipeline import DataPipeline
from src.eval.comparator import write_comparison
from src.eval.reporter import generate_report

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run unified commodity trend experiments.")
    parser.add_argument("--experiment", default="experiment", help="Experiment YAML name under src/config.")
    parser.add_argument("--models", default="", help="Comma-separated model names to run.")
    parser.add_argument("--smoke", action="store_true", help="Run only the first enabled model with short DL epochs.")
    parser.add_argument("overrides", nargs="*", help="Dotted overrides, e.g. data.test_start=2024-06-01.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    overrides = parse_overrides(args.overrides)
    exp_cfg = load_config(args.experiment)
    data_cfg = merge_dicts(load_config(exp_cfg.get("data_config", "data")), overrides.get("data", {}))
    seed_everything(int(exp_cfg.get("seed", 42)))
    bundle = DataPipeline(data_cfg).run()
    if args.smoke:
        bundle = slice_bundle(bundle, train_n=200, val_n=80, test_n=80)

    run_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{os.getpid()}"
    out_root = Path(exp_cfg.get("output_dir", "experiments")) / f"{run_id}_{exp_cfg.get('experiment_name', 'experiment')}"
    out_root.mkdir(parents=True, exist_ok=True)
    (out_root / "data_config.json").write_text(json.dumps(data_cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    requested = {m.strip() for m in args.models.split(",") if m.strip()}
    model_entries = [m for m in exp_cfg.get("models", []) if m.get("enabled", True)]
    if requested:
        model_entries = [m for m in model_entries if m["name"] in requested]
    if args.smoke and not requested and model_entries:
        model_entries = model_entries[:1]

    results: dict[str, dict[str, float]] = {}
    for entry in model_entries:
        model_cfg = load_config(entry["config"])
        model_name = model_cfg["name"]
        if args.smoke and model_cfg["class_path"].startswith("src.models.deep"):
            model_cfg.setdefault("params", {})["epochs"] = 2
        if args.smoke and model_name in {"random_forest", "xgboost", "lightgbm"}:
            model_cfg.setdefault("params", {})["n_estimators"] = min(int(model_cfg["params"].get("n_estimators", 20)), 20)
            if model_name in {"xgboost", "lightgbm"}:
                model_cfg["params"]["n_estimators"] = 5
                model_cfg["params"]["n_jobs"] = 1
                model_cfg["params"]["max_depth"] = min(int(model_cfg["params"].get("max_depth", 2)), 2)
            if model_name == "xgboost":
                model_cfg["params"]["n_estimators"] = 1
                model_cfg["params"]["tree_method"] = "hist"
                model_cfg["params"]["verbosity"] = 0
        print(f"\n=== {model_name} ===", flush=True)
        model = instantiate_model(model_cfg, bundle)
        model.fit(bundle.X_train, bundle.y_train, bundle.X_val, bundle.y_val)
        pred_scaled = model.predict(bundle.X_test)
        y_pred = bundle.y_scaler.inverse_transform(pred_scaled.reshape(-1, 1)).reshape(-1)
        y_true = bundle.y_scaler.inverse_transform(bundle.y_test.reshape(-1, 1)).reshape(-1)
        model_dir = out_root / model_name
        model_dir.mkdir(parents=True, exist_ok=True)
        model.save(model_dir / "model.pkl")
        metrics = generate_report(
            y_true=y_true,
            y_pred=y_pred,
            today_close=bundle.meta_test["today_close"].to_numpy(),
            model_name=model_name,
            output_dir=model_dir,
            meta=bundle.meta_test,
        )
        results[model_name] = metrics
        (model_dir / "model_config.json").write_text(json.dumps(model_cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    comparison = write_comparison(results, out_root)
    print("\n=== Comparison ===")
    print(comparison.to_string(index=False))


def instantiate_model(model_cfg: dict[str, Any], bundle):
    cls = import_from_path(model_cfg["class_path"])
    params = dict(model_cfg.get("params", {}))
    if model_cfg["class_path"].startswith("src.models.deep"):
        params.setdefault("input_size", bundle.X_train.shape[1])
        params.setdefault("seq_len", bundle.X_train.shape[2])
    else:
        params.setdefault("task", model_cfg.get("task", "regression"))
    return cls(**params)


def import_from_path(path: str):
    module_name, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_name)
    return getattr(module, class_name)


def slice_bundle(bundle, train_n: int, val_n: int, test_n: int):
    from dataclasses import replace

    return replace(
        bundle,
        X_train=bundle.X_train[:train_n],
        y_train=bundle.y_train[:train_n],
        X_val=bundle.X_val[:val_n],
        y_val=bundle.y_val[:val_n],
        X_test=bundle.X_test[:test_n],
        y_test=bundle.y_test[:test_n],
        meta_train=bundle.meta_train.iloc[:train_n].reset_index(drop=True),
        meta_val=bundle.meta_val.iloc[:val_n].reset_index(drop=True),
        meta_test=bundle.meta_test.iloc[:test_n].reset_index(drop=True),
    )


def parse_overrides(items: list[str]) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for item in items:
        if "=" not in item:
            continue
        key, raw = item.split("=", 1)
        value = coerce_value(raw)
        current = parsed
        parts = key.split(".")
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        current[parts[-1]] = value
    return parsed


def coerce_value(value: str) -> Any:
    if value.lower() in {"true", "false"}:
        return value.lower() == "true"
    for caster in (int, float):
        try:
            return caster(value)
        except ValueError:
            pass
    return value


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


if __name__ == "__main__":
    main()
